<?php

return [
    'default'=>env('MAIL_MAILER','log'),
    'mailers'=>[
        'smtp'=>['transport'=>'smtp','scheme'=>env('MAIL_SCHEME',env('MAIL_ENCRYPTION')),'url'=>env('MAIL_URL'),'host'=>env('MAIL_HOST',env('SMTP_HOST','127.0.0.1')),'port'=>env('MAIL_PORT',env('SMTP_PORT',2525)),'username'=>env('MAIL_USERNAME',env('SMTP_USER')),'password'=>env('MAIL_PASSWORD',env('SMTP_PASS')),'timeout'=>null,'local_domain'=>env('MAIL_EHLO_DOMAIN')],
        'log'=>['transport'=>'log','channel'=>env('MAIL_LOG_CHANNEL')],
        'array'=>['transport'=>'array'],
    ],
    'from'=>['address'=>env('MAIL_FROM_ADDRESS',env('FROM_EMAIL','hello@example.com')),'name'=>env('MAIL_FROM_NAME',env('APP_NAME','Laravel'))],
];
