<?php

return [
    'livekit' => ['url'=>env('LIVEKIT_URL'),'key'=>env('LIVEKIT_API_KEY'),'secret'=>env('LIVEKIT_API_SECRET')],
    'razorpay' => ['key_id'=>env('RAZORPAY_KEY_ID'),'key_secret'=>env('RAZORPAY_KEY_SECRET')],
    'payments' => ['upi_id'=>env('UPI_ID')],
    'realtime' => ['url'=>env('REALTIME_URL','http://127.0.0.1:5001'),'secret'=>env('REALTIME_SHARED_SECRET')],
];
