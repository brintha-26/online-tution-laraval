<?php

use App\Http\Controllers\Api\AdminController;
use App\Http\Controllers\Api\AssignmentController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\ClassroomController;
use App\Http\Controllers\Api\LivekitController;
use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\SubjectController;
use Illuminate\Support\Facades\Route;

Route::prefix('auth')->group(function (): void {
    Route::post('/signup', [AuthController::class, 'signup']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
    Route::post('/verify-otp', [AuthController::class, 'verifyOtp']);
    Route::post('/reset-password', [AuthController::class, 'resetPassword']);
    Route::middleware('auth:sanctum')->post('/logout', [AuthController::class, 'logout']);
    Route::middleware('auth:sanctum')->get('/me', [AuthController::class, 'me']);
});

Route::get('/payment/config', [PaymentController::class, 'config']);
Route::post('/livekit/webhook', [LivekitController::class, 'webhook']);

Route::middleware('auth:sanctum')->group(function (): void {
    Route::get('/assignments/recent-submissions', [AssignmentController::class, 'recentSubmissions']);
    Route::post('/assignments/{id}/submit', [AssignmentController::class, 'submit']);
    Route::put('/assignments/{id}/grade/{studentId}', [AssignmentController::class, 'grade']);
    Route::apiResource('assignments', AssignmentController::class)->parameters(['assignments'=>'id'])->except(['create','edit']);

    Route::post('/subjects/{id}/enroll', [SubjectController::class, 'enroll']);
    Route::post('/subjects/{id}/unenroll', [SubjectController::class, 'unenroll']);
    Route::apiResource('subjects', SubjectController::class)->parameters(['subjects'=>'id'])->except(['create','edit']);

    Route::get('/attendance/session/{roomId}', [ClassroomController::class, 'attendanceSession']);
    Route::get('/attendance/my-sessions', [ClassroomController::class, 'attendanceSessions']);
    Route::get('/attendance/my-history', [ClassroomController::class, 'attendanceHistory']);

    Route::get('/chat/conversations', [ClassroomController::class, 'conversations']);
    Route::get('/chat/messages/{partnerId}', [ClassroomController::class, 'messages']);
    Route::post('/chat/send', [ClassroomController::class, 'sendMessage']);
    Route::get('/chat/users', [ClassroomController::class, 'chatUsers']);

    Route::post('/livekit/create-room', [LivekitController::class, 'createRoom']);
    Route::get('/livekit/list-rooms', [LivekitController::class, 'listRooms']);
    Route::delete('/livekit/delete-room', [LivekitController::class, 'deleteRoom']);
    Route::get('/livekit/token', [LivekitController::class, 'token']);

    Route::get('/notifications', [ClassroomController::class, 'notifications']);
    Route::put('/notifications/read-all', [ClassroomController::class, 'markAllNotifications']);
    Route::put('/notifications/{id}/read', [ClassroomController::class, 'markNotification']);
    Route::post('/notifications/send', [ClassroomController::class, 'sendNotification']);

    Route::post('/payment/create-order', [PaymentController::class, 'createOrder']);
    Route::post('/payment/verify', [PaymentController::class, 'verify']);
    Route::post('/payment/submit-upi', [PaymentController::class, 'submitUpi']);
    Route::post('/payment/activate/{id}', [PaymentController::class, 'activate']);
    Route::post('/payment/reject/{id}', [PaymentController::class, 'reject']);

    Route::post('/progress/track', [ClassroomController::class, 'trackProgress']);
    Route::get('/progress/summary', [ClassroomController::class, 'progressSummary']);
    Route::post('/session/sync', [ClassroomController::class, 'syncSession']);
    Route::get('/session/{roomId}', [ClassroomController::class, 'getSession']);
    Route::get('/analytics/teacher', [ClassroomController::class, 'teacherAnalytics']);
    Route::get('/analytics/student', [ClassroomController::class, 'studentAnalytics']);

    Route::prefix('admin')->group(function (): void {
        Route::get('/users', [AdminController::class, 'users']);
        Route::post('/users/create', [AdminController::class, 'createUser']);
        Route::put('/users/{id}', [AdminController::class, 'updateUser']);
        Route::put('/users/{id}/access', [AdminController::class, 'updateUser']);
        Route::delete('/users/{id}', [AdminController::class, 'deleteUser']);
        Route::get('/payments', [AdminController::class, 'payments']);
        Route::post('/payments/{id}/approve', [AdminController::class, 'approvePayment']);
        Route::post('/payments/approve', [AdminController::class, 'approveManual']);
        Route::get('/stats', [AdminController::class, 'stats']);
    });
});
