import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import admin from 'firebase-admin';

const here = path.dirname(fileURLToPath(import.meta.url));
const credentialFile = process.env.FIREBASE_SERVICE_ACCOUNT_FILE;
const projectId = process.env.GOOGLE_CLOUD_PROJECT || process.env.VITE_FIREBASE_PROJECT_ID;
if (!projectId) throw new Error('Set GOOGLE_CLOUD_PROJECT to the Firebase project id.');
if (!credentialFile || !fs.existsSync(credentialFile)) {
  throw new Error('Set FIREBASE_SERVICE_ACCOUNT_FILE to a downloaded Firebase service-account JSON file.');
}

const credentials = JSON.parse(fs.readFileSync(credentialFile, 'utf8'));
admin.initializeApp({ projectId, credential: admin.credential.cert(credentials) });
const snapshot = await admin.firestore().collection('users').get();
const users = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
const destination = path.resolve(process.argv[2] || path.join(here, 'firestore-users.json'));
fs.writeFileSync(destination, JSON.stringify(users, null, 2), { mode: 0o600 });
console.log(`Exported ${users.length} user records to ${destination}`);
console.log('This file contains password hashes. Keep it private and delete it after importing.');
await admin.app().delete();
