#!/bin/sh
set -eu

if [ -n "${REALTIME_PUBLIC_URL:-}" ]; then
    php -r '$p="/var/www/html/public/index.html"; $s=file_get_contents($p); file_put_contents($p,str_replace("__REALTIME_URL__",getenv("REALTIME_PUBLIC_URL"),$s));'
fi

php artisan migrate --force
exec apache2-foreground
