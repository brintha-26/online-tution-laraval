<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('users', function (Blueprint $t) {
            $t->id(); $t->string('name',150); $t->string('email',190)->unique(); $t->timestamp('email_verified_at')->nullable(); $t->string('password');
            $t->string('role',30)->default('student'); $t->boolean('is_approved')->default(true); $t->timestamp('trial_start_date')->nullable();
            $t->timestamp('subscription_end_date')->nullable(); $t->string('avatar')->nullable(); $t->timestamp('last_active')->nullable();
            $t->string('reset_token')->nullable(); $t->timestamp('reset_token_expires_at')->nullable(); $t->rememberToken(); $t->timestamps();
        });
        Schema::create('personal_access_tokens', function (Blueprint $t) {
            $t->id(); $t->morphs('tokenable'); $t->string('name'); $t->string('token',64)->unique(); $t->text('abilities')->nullable(); $t->timestamp('last_used_at')->nullable(); $t->timestamp('expires_at')->nullable(); $t->timestamps();
        });
        Schema::create('password_reset_tokens', function (Blueprint $t) {
            $t->string('email')->primary(); $t->string('token'); $t->timestamp('created_at')->nullable();
        });
        Schema::create('subjects', function (Blueprint $t) {
            $t->id(); $t->string('name'); $t->text('description')->nullable(); $t->unsignedBigInteger('teacher_id')->index(); $t->json('enrolled_students')->nullable(); $t->json('syllabus')->nullable(); $t->json('schedule')->nullable(); $t->string('status')->default('active'); $t->text('cover_image')->nullable(); $t->timestamps();
        });
        Schema::create('assignments', function (Blueprint $t) {
            $t->id(); $t->string('title'); $t->text('description')->nullable(); $t->unsignedBigInteger('teacher_id')->index(); $t->unsignedBigInteger('subject_id')->nullable()->index(); $t->timestamp('due_date')->nullable(); $t->json('attachments')->nullable(); $t->string('status')->default('published'); $t->timestamps();
        });
        Schema::create('submissions', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('assignment_id')->index(); $t->unsignedBigInteger('student_id')->index(); $t->text('content')->nullable(); $t->json('attachments')->nullable(); $t->decimal('grade',8,2)->nullable(); $t->text('feedback')->nullable(); $t->timestamp('submitted_at')->nullable(); $t->timestamps();
        });
        Schema::create('attendance', function (Blueprint $t) {
            $t->id(); $t->string('room_id')->unique(); $t->unsignedBigInteger('teacher_id')->nullable()->index(); $t->string('session_title')->nullable(); $t->timestamp('session_date')->nullable()->index(); $t->json('records')->nullable(); $t->text('recording_url')->nullable(); $t->timestamps();
        });
        Schema::create('messages', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('sender_id')->index(); $t->unsignedBigInteger('receiver_id')->index(); $t->longText('content'); $t->string('type')->default('text'); $t->boolean('read')->default(false); $t->timestamps();
        });
        Schema::create('notifications', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('user_id')->index(); $t->string('title')->nullable(); $t->text('message')->nullable(); $t->boolean('read')->default(false); $t->text('link')->nullable(); $t->timestamps();
        });
        Schema::create('payments', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('user_id')->index(); $t->unsignedBigInteger('approved_by')->nullable(); $t->unsignedInteger('amount'); $t->unsignedInteger('days_added')->default(0); $t->string('status')->default('pending'); $t->string('method')->nullable(); $t->string('razorpay_order_id')->nullable(); $t->string('razorpay_payment_id')->nullable()->unique(); $t->string('razorpay_signature')->nullable(); $t->string('utr_number')->nullable(); $t->text('screenshot_url')->nullable(); $t->text('notes')->nullable(); $t->timestamps();
        });
        Schema::create('progress', function (Blueprint $t) {
            $t->id(); $t->unsignedBigInteger('student_id')->index(); $t->string('lesson_id')->index(); $t->boolean('watched')->default(true); $t->unsignedInteger('watch_time_seconds')->default(0); $t->timestamp('completed_at')->nullable(); $t->timestamps(); $t->unique(['student_id','lesson_id']);
        });
        Schema::create('session_data', function (Blueprint $t) {
            $t->id(); $t->string('room_id')->unique(); $t->unsignedBigInteger('teacher_id')->nullable()->index(); $t->json('highlights')->nullable(); $t->json('chat_history')->nullable(); $t->json('action_items')->nullable(); $t->json('payload')->nullable(); $t->timestamps();
        });
    }

    public function down(): void
    {
        foreach (['session_data','progress','payments','notifications','messages','attendance','submissions','assignments','subjects','password_reset_tokens','personal_access_tokens','users'] as $table) Schema::dropIfExists($table);
    }
};
