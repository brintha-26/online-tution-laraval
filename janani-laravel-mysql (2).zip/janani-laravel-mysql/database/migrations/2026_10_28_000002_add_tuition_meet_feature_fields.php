<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $t): void {
            $t->string('legacy_uid')->nullable()->unique();
            $t->string('reset_otp', 6)->nullable();
            $t->timestamp('reset_otp_expiry')->nullable();
            $t->unsignedTinyInteger('otp_request_count')->default(0);
            $t->timestamp('otp_reset_window')->nullable();
        });
        Schema::table('subjects', function (Blueprint $t): void { $t->json('lessons')->nullable(); });
        Schema::table('assignments', function (Blueprint $t): void { $t->unsignedInteger('max_points')->default(100); });
        Schema::table('submissions', function (Blueprint $t): void { $t->text('grade_feedback')->nullable(); $t->timestamp('graded_at')->nullable(); });
        Schema::table('notifications', function (Blueprint $t): void { $t->string('type')->nullable(); $t->unsignedBigInteger('assignment_id')->nullable()->index(); $t->unsignedBigInteger('sender_id')->nullable(); $t->timestamp('expires_at')->nullable(); });
        Schema::table('session_data', function (Blueprint $t): void { $t->string('title')->nullable(); });
    }

    public function down(): void
    {
        Schema::table('session_data', fn (Blueprint $t) => $t->dropColumn('title'));
        Schema::table('notifications', function (Blueprint $t): void { $t->dropIndex(['assignment_id']); $t->dropColumn(['type','assignment_id','sender_id','expires_at']); });
        Schema::table('submissions', fn (Blueprint $t) => $t->dropColumn(['grade_feedback','graded_at']));
        Schema::table('assignments', fn (Blueprint $t) => $t->dropColumn('max_points'));
        Schema::table('subjects', fn (Blueprint $t) => $t->dropColumn('lessons'));
        Schema::table('users', fn (Blueprint $t) => $t->dropColumn(['legacy_uid','reset_otp','reset_otp_expiry','otp_request_count','otp_reset_window']));
    }
};
