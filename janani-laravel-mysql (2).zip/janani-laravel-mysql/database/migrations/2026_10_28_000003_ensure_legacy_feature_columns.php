<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        $users=[];
        foreach(['legacy_uid'=>fn(Blueprint $t)=>$t->string('legacy_uid')->nullable()->unique(),'reset_otp'=>fn(Blueprint $t)=>$t->string('reset_otp',6)->nullable(),'reset_otp_expiry'=>fn(Blueprint $t)=>$t->timestamp('reset_otp_expiry')->nullable(),'otp_request_count'=>fn(Blueprint $t)=>$t->unsignedTinyInteger('otp_request_count')->default(0),'otp_reset_window'=>fn(Blueprint $t)=>$t->timestamp('otp_reset_window')->nullable()] as $column=>$add)if(!Schema::hasColumn('users',$column))$users[$column]=$add;
        if($users)Schema::table('users',function(Blueprint $t)use($users):void{foreach($users as $add)$add($t);});
        foreach(['subjects'=>['lessons'=>fn(Blueprint $t)=>$t->json('lessons')->nullable()],'assignments'=>['max_points'=>fn(Blueprint $t)=>$t->unsignedInteger('max_points')->default(100)],'submissions'=>['grade_feedback'=>fn(Blueprint $t)=>$t->text('grade_feedback')->nullable(),'graded_at'=>fn(Blueprint $t)=>$t->timestamp('graded_at')->nullable()],'notifications'=>['type'=>fn(Blueprint $t)=>$t->string('type')->nullable(),'assignment_id'=>fn(Blueprint $t)=>$t->unsignedBigInteger('assignment_id')->nullable(),'sender_id'=>fn(Blueprint $t)=>$t->unsignedBigInteger('sender_id')->nullable(),'expires_at'=>fn(Blueprint $t)=>$t->timestamp('expires_at')->nullable()],'session_data'=>['title'=>fn(Blueprint $t)=>$t->string('title')->nullable()]] as $table=>$columns){$missing=[];foreach($columns as $column=>$add)if(!Schema::hasColumn($table,$column))$missing[$column]=$add;if($missing)Schema::table($table,function(Blueprint $t)use($missing):void{foreach($missing as $add)$add($t);});}
    }
    public function down(): void {}
};
