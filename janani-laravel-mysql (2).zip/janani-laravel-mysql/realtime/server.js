import 'dotenv/config';
import { createServer } from 'node:http';
import { Server } from 'socket.io';

const host = process.env.REALTIME_HOST || '127.0.0.1';
const port = Number(process.env.REALTIME_PORT || 5001);
const apiBase = process.env.LARAVEL_API_BASE || 'http://127.0.0.1:8000/api';
const sharedSecret = process.env.REALTIME_SHARED_SECRET || '';
const allowedOrigins = (process.env.REALTIME_ALLOWED_ORIGINS || 'http://127.0.0.1:8000,http://localhost:8000').split(',');

const server = createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(JSON.stringify({ status: 'running' }));
  }
  const match = req.method === 'POST' && req.url.match(/^\/emit\/user\/(\d+)$/);
  if (!match) {
    res.writeHead(404); return res.end();
  }
  if (!sharedSecret || req.headers['x-realtime-key'] !== sharedSecret) {
    res.writeHead(401); return res.end();
  }
  let body = '';
  for await (const chunk of req) body += chunk;
  try {
    const payload = JSON.parse(body || '{}');
    io.to(`user:${match[1]}`).emit(payload.event || 'NOTIFICATION_NEW', payload.data || {});
    res.writeHead(202, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ sent: true }));
  } catch {
    res.writeHead(400); res.end();
  }
});

const io = new Server(server, {
  cors: { origin: allowedOrigins, credentials: true },
  transports: ['websocket', 'polling'],
});

io.use(async (socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('Authentication required'));
  try {
    const response = await fetch(`${apiBase}/auth/me`, {
      headers: { authorization: `Bearer ${token}`, accept: 'application/json' },
    });
    if (!response.ok) return next(new Error('Invalid or expired token'));
    const result = await response.json();
    socket.data.user = result.user;
    return next();
  } catch {
    return next(new Error('Laravel API is not reachable'));
  }
});

const roomMembers = new Map();
const userRooms = new Map();

function joinUserRoom(socket, id) {
  const userId = String(id || socket.data.user.id);
  if (userId !== String(socket.data.user.id)) return;
  socket.join(`user:${userId}`);
  userRooms.set(userId, (userRooms.get(userId) || new Set()).add(socket.id));
}

io.on('connection', (socket) => {
  socket.on('join-user', (id) => joinUserRoom(socket, id));
  socket.on('register-user', (id) => joinUserRoom(socket, id));

  socket.on('join-room', (roomId, clientInfo = {}) => {
    if (!roomId) return;
    const room = String(roomId);
    socket.data.activeRoom = room;
    socket.join(room);
    const members = roomMembers.get(room) || new Map();
    const user = socket.data.user;
    members.set(socket.id, { id: user.id, name: clientInfo.name || user.name, role: user.role, isStudent: user.role === 'student' });
    roomMembers.set(room, members);
    socket.to(room).emit('user-connected', user.id);
    io.to(room).emit('student-count', [...members.values()].filter((item) => item.isStudent).length);
  });

  socket.on('end-session', (data = {}) => {
    const room = String(data.roomId || socket.data.activeRoom || '');
    if (room && socket.data.user.role === 'teacher') io.to(room).emit('session-ended', { roomId: room, endedAt: data.endedAt || Date.now() });
  });

  socket.on('private-message', (message = {}) => {
    if (!message.receiverId) return;
    io.to(`user:${message.receiverId}`).emit('private-message', { ...message, senderId: socket.data.user.id });
  });
  socket.on('typing', (data = {}) => { if (data.receiverId) io.to(`user:${data.receiverId}`).emit('typing', { ...data, senderId: socket.data.user.id }); });
  socket.on('stop-typing', (data = {}) => { if (data.receiverId) io.to(`user:${data.receiverId}`).emit('stop-typing', { ...data, senderId: socket.data.user.id }); });
  socket.on('chat-message', (message = {}) => { if (socket.data.activeRoom) socket.to(socket.data.activeRoom).emit('chat-message', { ...message, senderId: socket.data.user.id }); });
  socket.on('signal', (data = {}) => { if (data.to) io.to(`user:${data.to}`).emit('signal', { ...data, from: socket.data.user.id }); });

  socket.on('disconnect', () => {
    const room = socket.data.activeRoom;
    if (room && roomMembers.has(room)) {
      const members = roomMembers.get(room);
      members.delete(socket.id);
      socket.to(room).emit('user-disconnected', socket.data.user.id);
      io.to(room).emit('student-count', [...members.values()].filter((item) => item.isStudent).length);
      if (!members.size) roomMembers.delete(room);
    }
    for (const [userId, sockets] of userRooms) {
      sockets.delete(socket.id);
      if (!sockets.size) userRooms.delete(userId);
    }
  });
});

server.listen(port, host, () => console.log(`Realtime relay listening on http://${host}:${port}`));
