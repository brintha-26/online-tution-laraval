<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ApiCaseTransformer
{
    public function handle(Request $request, Closure $next): Response
    {
        if ($request->is('api/*')) {
            $source = $request->isJson() ? $request->json() : $request->request;
            $source->replace($this->mapKeys($source->all(), 'snake'));
            $request->query->replace($this->mapKeys($request->query->all(), 'snake'));
        }

        $response = $next($request);
        if ($request->is('api/*') && str_contains((string)$response->headers->get('Content-Type'), 'application/json')) {
            $data = json_decode((string)$response->getContent(), true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $response->setContent(json_encode($this->mapKeys($data, 'camel'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            }
        }
        return $response;
    }

    private function mapKeys(mixed $value, string $style): mixed
    {
        if (!is_array($value)) return $value;
        $mapped = [];
        foreach ($value as $key => $item) {
            if (is_string($key)) {
                $key = $style === 'snake'
                    ? strtolower((string)preg_replace('/([a-z0-9])([A-Z])/', '$1_$2', $key))
                    : lcfirst(str_replace(' ', '', ucwords(str_replace(['-', '_'], ' ', $key))));
            }
            $mapped[$key] = $this->mapKeys($item, $style);
        }
        return $mapped;
    }
}
