<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Assignment;
use App\Models\Attendance;
use App\Models\Message;
use App\Models\Notification;
use App\Models\Progress;
use App\Models\SessionData;
use App\Models\Subject;
use App\Models\Submission;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class ClassroomController extends Controller
{
    public function attendanceSession(Request $r, string $roomId): JsonResponse
    {
        $item = Attendance::where('room_id', $roomId)->firstOrFail();
        abort_unless($r->user()->role === 'admin' || (int)$item->teacher_id === (int)$r->user()->id, 403);
        return response()->json($item);
    }

    public function attendanceSessions(Request $r): JsonResponse
    {
        return response()->json(Attendance::where('teacher_id', $r->user()->id)->latest('session_date')->limit(50)->get());
    }

    public function attendanceHistory(Request $r): JsonResponse
    {
        $out = [];
        foreach (Attendance::orderByDesc('session_date')->get() as $session) {
            foreach (($session->records ?? []) as $record) {
                if ((string)($record['userId'] ?? $record['user_id'] ?? '') !== (string)$r->user()->id) continue;
                $out[] = ['roomId'=>$session->room_id,'sessionTitle'=>$session->session_title,'sessionDate'=>$session->session_date,'joinedAt'=>$record['joinedAt'] ?? $record['joined_at'] ?? null,'leftAt'=>$record['leftAt'] ?? $record['left_at'] ?? null,'duration'=>$record['duration'] ?? 0];
            }
        }
        return response()->json($out);
    }

    public function conversations(Request $r): JsonResponse
    {
        $id = (int)$r->user()->id;
        $partnerIds = Message::where('sender_id',$id)->pluck('receiver_id')->merge(Message::where('receiver_id',$id)->pluck('sender_id'))->unique()->values();
        $users = User::whereIn('id',$partnerIds)->where('role','!=','admin')->get();
        $out = $users->map(function (User $partner) use ($id): array {
            $pair = Message::where(fn($q) => $q->where('sender_id',$id)->where('receiver_id',$partner->id))->orWhere(fn($q) => $q->where('sender_id',$partner->id)->where('receiver_id',$id));
            $last = (clone $pair)->latest()->first();
            return ['partner'=>['id'=>$partner->id,'name'=>$partner->name,'role'=>$partner->role,'avatar'=>$partner->avatar], 'lastMessage'=>$last ? ['content'=>$last->content,'createdAt'=>$last->created_at,'senderId'=>$last->sender_id] : null, 'unreadCount'=>Message::where('sender_id',$partner->id)->where('receiver_id',$id)->where('read',false)->count()];
        })->sortByDesc(fn($c) => $c['lastMessage']['createdAt'] ?? '')->values();
        return response()->json($out);
    }

    public function messages(Request $r, int $partnerId): JsonResponse
    {
        $id=(int)$r->user()->id;
        $q=Message::where(fn($x)=>$x->where('sender_id',$id)->where('receiver_id',$partnerId))->orWhere(fn($x)=>$x->where('sender_id',$partnerId)->where('receiver_id',$id));
        $rows=(clone $q)->latest()->paginate(50,['*'],'page',max(1,(int)$r->query('page',1)));
        Message::where('sender_id',$partnerId)->where('receiver_id',$id)->where('read',false)->update(['read'=>true]);
        return response()->json(collect($rows->items())->reverse()->values());
    }

    public function sendMessage(Request $r): JsonResponse
    {
        $data=$r->validate(['receiver_id'=>['required','exists:users,id'],'content'=>['required','string','max:10000'],'type'=>['nullable','string','max:30']]);
        $m=Message::create(['sender_id'=>$r->user()->id,'receiver_id'=>$data['receiver_id'],'content'=>$data['content'],'type'=>$data['type']??'text','read'=>false]);
        return response()->json($m,201);
    }

    public function chatUsers(Request $r): JsonResponse
    {
        $q=User::where('id','!=',$r->user()->id)->where('role','!=','admin');
        if ($r->filled('q')) $q->where('name','like','%'.$r->query('q').'%');
        return response()->json($q->limit(20)->get(['id','name','email','role','avatar']));
    }

    public function notifications(Request $r): JsonResponse
    {
        $page=max(1,(int)$r->query('page',1));$limit=min(100,max(1,(int)$r->query('limit',20)));$query=Notification::where('user_id',$r->user()->id)->latest();
        $count=(clone $query)->count();$unread=Notification::where('user_id',$r->user()->id)->where('read',false)->count();
        return response()->json(['notifications'=>$query->skip(($page-1)*$limit)->take($limit)->get()->map(fn($n)=>$this->notificationPayload($n)),'unreadCount'=>$unread,'page'=>$page,'limit'=>$limit,'total'=>$count]);
    }

    public function markNotification(Request $r, int $id): JsonResponse
    {
        $n=Notification::where('user_id',$r->user()->id)->findOrFail($id); $n->read=true; $n->save();
        return response()->json(['message'=>'Notification marked as read','notification'=>$this->notificationPayload($n)]);
    }

    public function markAllNotifications(Request $r): JsonResponse
    {
        Notification::where('user_id',$r->user()->id)->where('read',false)->update(['read'=>true]);
        return response()->json(['message'=>'All notifications marked as read']);
    }

    public function sendNotification(Request $r): JsonResponse
    {
        abort_unless($r->user()->role==='teacher',403);
        $data=$r->validate(['title'=>['required','string','max:190'],'message'=>['nullable','string','max:2000'],'desc'=>['nullable','string','max:2000'],'type'=>['nullable','string','max:40'],'link'=>['nullable','string','max:500'],'user_id'=>['nullable','exists:users,id'],'user_ids'=>['nullable','array','min:1'],'user_ids.*'=>['integer','exists:users,id'],'subject_id'=>['nullable','exists:subjects,id'],'expires_in_days'=>['nullable','integer','min:1','max:365']]);
        $ids=collect();
        if (!empty($data['user_id'])) $ids->push((int)$data['user_id']);
        elseif (!empty($data['user_ids'])) $ids=collect($data['user_ids'])->map(fn($v)=>(int)$v);
        elseif (!empty($data['subject_id'])) $ids=collect(Subject::findOrFail($data['subject_id'])->enrolled_students ?? [])->map(fn($v)=>(int)$v);
        else $ids=User::where('role','student')->pluck('id');
        $rows=$ids->unique()->map(fn($uid)=>Notification::create(['user_id'=>$uid,'sender_id'=>$r->user()->id,'title'=>$data['title'],'message'=>$data['message']??$data['desc']??'','type'=>$data['type']??'announcement','link'=>$data['link']??'','read'=>false,'expires_at'=>now()->addDays($data['expires_in_days']??7)]));
        foreach($rows as $notification)$this->emitNotification($notification);
        return response()->json(['message'=>'Notifications sent','count'=>$rows->count()],201);
    }

    public function emitNotification(Notification $n): void
    {
        $secret=config('services.realtime.secret');$url=config('services.realtime.url');if(!$secret||!$url)return;
        try{Http::timeout(1)->withHeader('X-Realtime-Key',$secret)->post(rtrim($url,'/').'/emit/user/'.$n->user_id,['event'=>'NOTIFICATION_NEW','data'=>$this->notificationPayload($n)]);}catch(\Throwable $e){report($e);}
    }

    private function notificationPayload(Notification $n): array
    {
        return ['id'=>$n->id,'type'=>$n->type??'announcement','title'=>$n->title??'Notification','desc'=>$n->message??'','time'=>$n->created_at,'unread'=>!$n->read,'read'=>(bool)$n->read,'assignmentId'=>$n->assignment_id,'link'=>$n->link,'senderId'=>User::find($n->sender_id)?->only(['id','name'])];
    }

    public function syncSession(Request $r): JsonResponse
    {
        $data=$r->validate(['room_id'=>['required','string','max:190'],'highlights'=>['nullable','array'],'action_items'=>['nullable','array'],'chat_history'=>['nullable','array'],'title'=>['nullable','string','max:190']]);
        foreach (['highlights','chat_history'] as $key) if (isset($data[$key])) $data[$key]=array_map(fn($item)=>is_array($item)?array_map(fn($v)=>is_string($v)?strip_tags($v):$v,$item):$item,$data[$key]);
        $session=SessionData::firstOrNew(['room_id'=>$data['room_id']]);
        if (!$session->exists) $session->teacher_id=$r->user()->id;
        abort_unless($r->user()->role==='admin'||(int)$session->teacher_id===(int)$r->user()->id,403);
        foreach (['highlights'=>'highlights','action_items'=>'action_items','chat_history'=>'chat_history','title'=>'title'] as $input=>$column) if (array_key_exists($input,$data)) $session->{$column}=$data[$input];
        $session->save();
        return response()->json($session);
    }

    public function getSession(Request $r, string $roomId): JsonResponse
    {
        $s=SessionData::where('room_id',$roomId)->firstOrFail();
        abort_unless($r->user()->role==='admin'||(int)$s->teacher_id===(int)$r->user()->id,403);
        return response()->json($s);
    }

    public function trackProgress(Request $r): JsonResponse
    {
        $d=$r->validate(['lesson_id'=>['required','string','max:190'],'subject_id'=>['required','integer','exists:subjects,id'],'watch_time_seconds'=>['nullable','integer','min:0']]);
        $p=Progress::updateOrCreate(['student_id'=>$r->user()->id,'lesson_id'=>$d['lesson_id']],['subject_id'=>$d['subject_id'],'watched'=>true,'watch_time_seconds'=>$d['watch_time_seconds']??0,'completed_at'=>now()]);
        return response()->json($p);
    }

    public function progressSummary(Request $r): JsonResponse
    {
        $records=Progress::where('student_id',$r->user()->id)->get(); $by=[]; $seconds=0;
        foreach($records as $p){$key=(string)$p->subject_id;$subject=Subject::find($p->subject_id);$by[$key]??=['name'=>$subject?->name??'Unknown','watched'=>0];$by[$key]['watched']++;$seconds+=(int)$p->watch_time_seconds;}
        return response()->json(['totalLessonsWatched'=>$records->count(),'totalStudyHours'=>round($seconds/3600,1),'subjects'=>array_values($by)]);
    }

    public function teacherAnalytics(Request $r): JsonResponse
    {
        $id=$r->user()->id; $subjects=Subject::where('teacher_id',$id)->get();$assignments=Assignment::where('teacher_id',$id)->get();$ids=$assignments->pluck('id');$subs=Submission::whereIn('assignment_id',$ids)->get();$sessions=Attendance::where('teacher_id',$id)->latest('session_date')->get();
        $students=$subjects->flatMap(fn($s)=>$s->enrolled_students??[])->unique();$attendees=$sessions->sum(fn($s)=>count($s->records??[]));
        return response()->json(['totalStudents'=>$students->count(),'totalSubjects'=>$subjects->count(),'totalAssignments'=>$assignments->count(),'totalSubmissions'=>$subs->count(),'gradedSubmissions'=>$subs->whereNotNull('grade')->count(),'pendingGrades'=>$subs->whereNull('grade')->count(),'totalSessions'=>$sessions->count(),'avgAttendance'=>$sessions->count()?round($attendees/$sessions->count()):0,'recentSessions'=>$sessions->take(5)->map(fn($s)=>['roomId'=>$s->room_id,'title'=>$s->session_title??$s->room_id,'date'=>$s->session_date,'attendees'=>count($s->records??[]),'recordingUrl'=>$s->recording_url]),'subjectNames'=>$subjects->map(fn($s)=>['id'=>$s->id,'name'=>$s->name,'students'=>count($s->enrolled_students??[])])]);
    }

    public function studentAnalytics(Request $r): JsonResponse
    {
        $id=$r->user()->id;$subjects=Subject::whereJsonContains('enrolled_students',$id)->get();$assignments=Assignment::where('status','published')->get();$subs=Submission::where('student_id',$id)->whereIn('assignment_id',$assignments->pluck('id'))->get();$attended=0;$minutes=0;
        foreach(Attendance::all() as $session) foreach($session->records??[] as $record) if((string)($record['userId']??$record['user_id']??'')===(string)$id){$attended++;$minutes+=($record['duration']??0)/60;}
        $grades=$subs->whereNotNull('grade')->pluck('grade');
        return response()->json(['enrolledSubjects'=>$subjects->count(),'totalAssignments'=>$assignments->count(),'submittedAssignments'=>$subs->count(),'averageGrade'=>$grades->count()?round($grades->avg()):null,'sessionsAttended'=>$attended,'studyHours'=>round($minutes/60,1),'subjectProgress'=>$subjects->map(fn($s)=>['id'=>$s->id,'name'=>$s->name,'totalLessons'=>count($s->lessons??[])])]);
    }
}
