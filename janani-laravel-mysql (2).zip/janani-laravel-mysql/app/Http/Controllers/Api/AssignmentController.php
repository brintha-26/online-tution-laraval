<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Assignment;
use App\Models\Notification;
use App\Models\Subject;
use App\Models\Submission;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AssignmentController extends Controller
{
    public function index(Request $r): JsonResponse
    {
        if ($r->user()->role === 'teacher') {
            $rows=Assignment::where('teacher_id',$r->user()->id)->latest()->get();
            return response()->json($rows->map(function($a){$x=$a->toArray();$x['submission_count']=Submission::where('assignment_id',$a->id)->count();return $x;}));
        }
        $rows=Assignment::where('status','published')->orderBy('due_date')->get();
        if ($r->user()->role==='student') {
            $subs=Submission::where('student_id',$r->user()->id)->get()->keyBy('assignment_id');
            $rows=$rows->map(function($a)use($subs){$s=$subs->get($a->id);$x=$a->toArray();$x['submitted']=(bool)$s;$x['grade']=$s? $this->gradePayload($s):null;return $x;});
        }
        return response()->json($rows);
    }

    public function show(Request $r, int $id): JsonResponse
    {
        $a=Assignment::findOrFail($id);$out=$a->toArray();
        if ($r->user()->role==='teacher' && (int)$a->teacher_id===(int)$r->user()->id) {
            $out['submissions']=Submission::where('assignment_id',$a->id)->latest('submitted_at')->get()->map(fn($s)=>$this->submissionPayload($s));
        } elseif($r->user()->role==='student') {
            $s=Submission::where('assignment_id',$a->id)->where('student_id',$r->user()->id)->first();$out['my_submission']=$s?$this->submissionPayload($s):null;
        }
        return response()->json($out);
    }

    public function store(Request $r): JsonResponse
    {
        abort_unless($r->user()->role==='teacher',403);
        $d=$r->validate(['title'=>['required','string','max:190'],'description'=>['nullable','string'],'subject_id'=>['required','exists:subjects,id'],'due_date'=>['nullable','date'],'max_points'=>['nullable','integer','min:1'],'attachments'=>['nullable','array']]);
        $a=Assignment::create($d+['teacher_id'=>$r->user()->id,'attachments'=>$d['attachments']??[],'status'=>'published']);
        $subject=Subject::find($a->subject_id);
        foreach($subject?->enrolled_students??[] as $uid) Notification::create(['user_id'=>$uid,'type'=>'assignment','title'=>'New Assignment','message'=>'New assignment: '.$a->title,'link'=>'/assignments','read'=>false]);
        return response()->json($a,201);
    }

    public function update(Request $r, int $id): JsonResponse
    {
        $a=Assignment::where('teacher_id',$r->user()->id)->findOrFail($id);
        $d=$r->validate(['title'=>['sometimes','string','max:190'],'description'=>['sometimes','nullable','string'],'subject_id'=>['sometimes','exists:subjects,id'],'due_date'=>['sometimes','nullable','date'],'max_points'=>['sometimes','integer','min:1'],'attachments'=>['sometimes','array'],'status'=>['sometimes','in:published,closed,draft']]);
        $a->fill($d)->save();return response()->json($a);
    }

    public function destroy(Request $r, int $id): JsonResponse
    {
        $a=Assignment::where('teacher_id',$r->user()->id)->findOrFail($id);
        DB::transaction(fn()=>Submission::where('assignment_id',$a->id)->delete());$a->delete();
        return response()->json(['message'=>'Assignment and associated submissions deleted']);
    }

    public function submit(Request $r, int $id): JsonResponse
    {
        abort_unless($r->user()->role==='student',403);$a=Assignment::findOrFail($id);
        if($a->status==='closed')return response()->json(['message'=>'Assignment is closed for submissions'],400);
        $d=$r->validate(['content'=>['nullable','string','max:20000'],'attachments'=>['nullable','array']]);
        $s=Submission::updateOrCreate(['assignment_id'=>$id,'student_id'=>$r->user()->id],['content'=>$d['content']??'','attachments'=>$d['attachments']??[],'submitted_at'=>now()]);
        return response()->json(['message'=>'Submission saved','submission'=>$this->submissionPayload($s)]);
    }

    public function grade(Request $r, int $id, int $studentId): JsonResponse
    {
        $a=Assignment::where('teacher_id',$r->user()->id)->findOrFail($id);
        $d=$r->validate(['points'=>['required','numeric','min:0','max:'.$a->max_points],'feedback'=>['nullable','string','max:5000']]);
        $s=Submission::where('assignment_id',$id)->where('student_id',$studentId)->firstOrFail();
        $s->grade=$d['points'];$s->grade_feedback=$d['feedback']??'';$s->graded_at=now();$s->save();
        $notification=Notification::create(['user_id'=>$studentId,'type'=>'grade','title'=>'Assignment Graded','message'=>'Your assignment "'.$a->title.'" has been graded!','assignment_id'=>$id,'link'=>'/assignments','read'=>false]);
        app(ClassroomController::class)->emitNotification($notification);
        return response()->json(['message'=>'Grade saved','submission'=>$this->submissionPayload($s)]);
    }

    public function recentSubmissions(Request $r): JsonResponse
    {
        $ids=Assignment::where('teacher_id',$r->user()->id)->pluck('id');
        return response()->json(Submission::whereIn('assignment_id',$ids)->latest('submitted_at')->limit(10)->get()->map(function($s){$a=Assignment::find($s->assignment_id);$u=User::find($s->student_id);return ['id'=>$s->id,'title'=>$a?->title,'student_name'=>$u?->name,'submitted_at'=>$s->submitted_at?->toDateTimeString(),'file_name'=>$s->attachments[0]['name']??'submission.pdf','status'=>$s->grade!==null?'Graded':'Pending','feedback'=>$s->grade_feedback];}));
    }

    private function gradePayload(Submission $s): ?array { return $s->grade===null?null:['points'=>(float)$s->grade,'feedback'=>$s->grade_feedback,'graded_at'=>$s->graded_at]; }
    private function submissionPayload(Submission $s): array { $x=$s->toArray();$x['grade']=$this->gradePayload($s);$x['student_id']=User::find($s->student_id)?->only(['id','name','email']);$x['assignment_id']=Assignment::find($s->assignment_id)?->only(['id','title']);return $x; }
}
