<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Assignment;
use App\Models\Payment;
use App\Models\Subject;
use App\Models\Submission;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    private function admin(Request $r): void { abort_unless($r->user()->role==='admin',403); }
    public function users(Request $r):JsonResponse{$this->admin($r);$q=User::query();if($r->filled('role'))$q->where('role',$r->query('role'));return response()->json($q->latest()->get()->map(fn($u)=>$u->makeVisible(['trial_start_date','subscription_end_date'])));}
    public function updateUser(Request $r,int $id):JsonResponse
    {
        $this->admin($r);$u=User::findOrFail($id);$d=$r->validate(['role'=>['sometimes','in:student,teacher,admin'],'subscription_end_date'=>['sometimes','nullable','date'],'trial_start_date'=>['sometimes','nullable','date'],'is_approved'=>['sometimes','boolean'],'name'=>['sometimes','string','max:150']]);$u->fill($d)->save();return response()->json(['message'=>'User access updated successfully','user'=>$u]);
    }
    public function createUser(Request $r):JsonResponse
    {
        $this->admin($r);$d=$r->validate(['name'=>['required','string','max:150'],'email'=>['required','email','unique:users,email'],'password'=>['required','string','min:6'],'role'=>['required','in:student,teacher,admin']]);$u=User::create($d+['is_approved'=>true,'trial_start_date'=>now()]);return response()->json(['message'=>'Account created for '.$u->name,'user'=>$u],201);
    }
    public function deleteUser(Request $r,int $id):JsonResponse{$this->admin($r);$u=User::findOrFail($id);$u->tokens()->delete();$u->delete();return response()->json(['message'=>'User deleted successfully']);}
    public function payments(Request $r):JsonResponse{$this->admin($r);$rows=Payment::latest()->limit(100)->get()->map(function($p){$p->setAttribute('user_id',User::find($p->user_id)?->only(['id','name','email']));return $p;});return response()->json($rows);}
    public function approvePayment(Request $r,int $id):JsonResponse
    {
        $this->admin($r);$d=$r->validate(['days'=>['nullable','integer','min:1','max:365']]);$p=Payment::findOrFail($id);if($p->status==='approved')return response()->json(['message'=>'Payment already approved'],400);$u=User::findOrFail($p->user_id);$days=(int)($d['days']??$p->days_added);$this->extend($u,$days);$p->status='approved';$p->days_added=$days;$p->approved_by=$r->user()->id;$p->save();return response()->json(['message'=>'Payment approved and subscription extended','user'=>$u->fresh(),'payment'=>$p]);
    }
    public function approveManual(Request $r):JsonResponse
    {
        $this->admin($r);$d=$r->validate(['user_id'=>['required','exists:users,id'],'amount'=>['required','integer','min:0'],'days_added'=>['required','integer','min:1','max:365'],'notes'=>['nullable','string']]);$u=User::findOrFail($d['user_id']);
        return DB::transaction(function()use($u,$d,$r){$this->extend($u,$d['days_added']);$p=Payment::create(['user_id'=>$u->id,'amount'=>$d['amount'],'days_added'=>$d['days_added'],'status'=>'approved','notes'=>$d['notes']??'','approved_by'=>$r->user()->id,'method'=>'admin']);return response()->json(['message'=>'Payment approved and subscription extended','user'=>$u->fresh(),'payment'=>$p]);});
    }
    public function stats(Request $r):JsonResponse
    {
        $this->admin($r);$now=now();$students=User::where('role','student')->count();$active=User::where('role','student')->where(fn($q)=>$q->where('subscription_end_date','>',$now)->orWhere('trial_start_date','>',now()->subDays(7)))->count();$paid=Payment::where('status','approved');
        return response()->json(['totalStudents'=>$students,'totalTeachers'=>User::where('role','teacher')->count(),'activeStudents'=>User::where('role','student')->where('last_active','>=',now()->subMinutes(15))->count(),'onlineTeachers'=>User::where('role','teacher')->where('last_active','>=',now()->subMinutes(15))->count(),'blockedStudents'=>max(0,$students-$active),'totalRevenue'=>(int)$paid->sum('amount'),'recentPayments'=>(clone $paid)->latest()->limit(5)->get()->map(function($p){$p->setAttribute('user_id',User::find($p->user_id)?->only(['id','name','email']));return $p;})]);
    }
    private function extend(User $u,int $days):void{$base=$u->subscription_end_date&&$u->subscription_end_date->isFuture()?$u->subscription_end_date:now();$u->subscription_end_date=$base->copy()->addDays($days);$u->save();}
}
