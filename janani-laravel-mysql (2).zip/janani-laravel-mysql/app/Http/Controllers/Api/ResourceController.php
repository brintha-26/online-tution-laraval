<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ResourceController extends Controller
{
    private const MODELS = [
        'assignments' => \App\Models\Assignment::class,
        'attendance' => \App\Models\Attendance::class,
        'messages' => \App\Models\Message::class,
        'notifications' => \App\Models\Notification::class,
        'payments' => \App\Models\Payment::class,
        'progress' => \App\Models\Progress::class,
        'sessions' => \App\Models\SessionData::class,
        'subjects' => \App\Models\Subject::class,
        'submissions' => \App\Models\Submission::class,
    ];

    private function model(Request $request): Model
    {
        $class = self::MODELS[$request->route('resource')] ?? abort(404);
        return new $class();
    }

    public function index(Request $request): JsonResponse
    {
        $model = $this->model($request);
        $query = $model->newQuery();
        $user = $request->user();
        if ($user->role !== 'admin') {
            $ownerField = $model->ownerField();
            if ($ownerField) $query->where($ownerField, $user->id);
        }
        foreach (['teacher_id','student_id','subject_id','assignment_id','user_id','status'] as $filter) {
            if ($request->filled($filter)) $query->where($filter, $request->input($filter));
        }
        return response()->json($query->latest()->paginate(min((int) $request->input('per_page', 50), 100)));
    }

    public function store(Request $request): JsonResponse
    {
        $model = $this->model($request);
        $data = $request->except(['id','created_at','updated_at']);
        $ownerField = $model->ownerField();
        if ($ownerField) $data[$ownerField] = $request->user()->id;
        $item = $model->newQuery()->create($data);
        return response()->json($item, 201);
    }

    public function show(Request $request, string $id): JsonResponse
    {
        return response()->json($this->owned($request, $id));
    }

    public function update(Request $request, string $id): JsonResponse
    {
        $item = $this->owned($request, $id);
        $item->fill($request->except(['id','created_at','updated_at', $item->ownerField()]))->save();
        return response()->json($item->refresh());
    }

    public function destroy(Request $request, string $id): JsonResponse
    {
        $this->owned($request, $id)->delete();
        return response()->json(['message' => 'Deleted']);
    }

    private function owned(Request $request, string $id): Model
    {
        $model = $this->model($request);
        $query = $model->newQuery();
        $ownerField = $model->ownerField();
        if ($request->user()->role !== 'admin' && $ownerField) $query->where($ownerField, $request->user()->id);
        return $query->findOrFail($id);
    }
}
