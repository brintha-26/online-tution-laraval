<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Subject;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SubjectController extends Controller
{
    public function index(Request $r): JsonResponse
    {
        $q=Subject::query();
        if($r->user()->role==='teacher')$q->where('teacher_id',$r->user()->id);
        else $q->where('status','active')->orderBy('name');
        $rows=$q->latest()->get();
        if($r->user()->role!=='teacher')$rows->each(function($s){$s->setAttribute('teacher_id',\App\Models\User::find($s->teacher_id)?->only(['id','name','email']));});
        return response()->json($rows);
    }
    public function show(Request $r,int $id):JsonResponse{$s=Subject::findOrFail($id);$s->setAttribute('teacher_id',\App\Models\User::find($s->teacher_id)?->only(['id','name','email']));$s->setAttribute('enrolled_students',\App\Models\User::whereIn('id',$s->enrolled_students??[])->get(['id','name','email']));return response()->json($s);}
    public function store(Request $r):JsonResponse
    {
        abort_unless($r->user()->role==='teacher',403);
        $d=$r->validate(['name'=>['required','string','max:190'],'description'=>['nullable','string'],'cover_image'=>['nullable','string','max:2000'],'syllabus'=>['nullable','array'],'lessons'=>['nullable','array'],'schedule'=>['nullable','array']]);
        return response()->json(Subject::create($d+['teacher_id'=>$r->user()->id,'enrolled_students'=>[],'status'=>'active']),201);
    }
    public function update(Request $r,int $id):JsonResponse
    {
        abort_unless($r->user()->role==='teacher',403);$s=Subject::where('teacher_id',$r->user()->id)->findOrFail($id);
        $d=$r->validate(['name'=>['sometimes','string','max:190'],'description'=>['sometimes','nullable','string'],'cover_image'=>['sometimes','nullable','string','max:2000'],'syllabus'=>['sometimes','array'],'lessons'=>['sometimes','array'],'schedule'=>['sometimes','array'],'status'=>['sometimes','in:active,inactive']]);
        $s->fill($d)->save();return response()->json($s);
    }
    public function destroy(Request $r,int $id):JsonResponse
    {
        abort_unless($r->user()->role==='teacher',403);$s=Subject::where('teacher_id',$r->user()->id)->findOrFail($id);$s->delete();return response()->json(['message'=>'Subject deleted']);
    }
    public function enroll(Request $r,int $id):JsonResponse
    {
        abort_unless($r->user()->role==='student',403);$s=Subject::findOrFail($id);$ids=array_map('intval',$s->enrolled_students??[]);$uid=(int)$r->user()->id;
        if(in_array($uid,$ids,true))return response()->json(['message'=>'Already enrolled'],400);$ids[]=$uid;$s->enrolled_students=$ids;$s->save();return response()->json(['message'=>'Enrolled successfully','subject'=>$s]);
    }
    public function unenroll(Request $r,int $id):JsonResponse
    {
        abort_unless($r->user()->role==='student',403);$s=Subject::findOrFail($id);$s->enrolled_students=array_values(array_filter($s->enrolled_students??[],fn($v)=>(int)$v!==(int)$r->user()->id));$s->save();return response()->json(['message'=>'Unenrolled successfully']);
    }
}
