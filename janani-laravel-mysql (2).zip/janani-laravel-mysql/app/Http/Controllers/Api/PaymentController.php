<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class PaymentController extends Controller
{
    public function config():JsonResponse{$key=config('services.razorpay.key_id');return response()->json(['enabled'=>(bool)$key,'keyId'=>$key??'','upiId'=>config('services.payments.upi_id')??'','currency'=>'INR']);}

    public function createOrder(Request $r):JsonResponse
    {
        $d=$r->validate(['days'=>['required','integer','min:1','max:365'],'amount'=>['required','integer','min:1']]);$expected=$this->price($d['days']);
        if($expected===null||$d['amount']!==$expected)return response()->json(['message'=>'Payment details mismatch'],400);
        $key=config('services.razorpay.key_id');$secret=config('services.razorpay.key_secret');if(!$key||!$secret)return response()->json(['message'=>'Razorpay is not configured'],503);
        $res=Http::withBasicAuth($key,$secret)->post('https://api.razorpay.com/v1/orders',['amount'=>$expected*100,'currency'=>'INR','receipt'=>'tm_'.Str::uuid(),'notes'=>['user_id'=>(string)$r->user()->id,'days'=>(string)$d['days']]]);
        if(!$res->successful())return response()->json(['message'=>'Could not create payment order'],502);
        $order=$res->json();Payment::create(['user_id'=>$r->user()->id,'amount'=>$expected,'days_added'=>$d['days'],'status'=>'pending','method'=>'razorpay','razorpay_order_id'=>$order['id'],'notes'=>'Razorpay order created']);
        return response()->json(['orderId'=>$order['id'],'amount'=>$order['amount'],'currency'=>$order['currency'],'keyId'=>$key]);
    }

    public function verify(Request $r):JsonResponse
    {
        $d=$r->validate(['razorpay_order_id'=>['required','string'],'razorpay_payment_id'=>['required','string'],'razorpay_signature'=>['required','string'],'days'=>['required','integer','min:1','max:365'],'amount'=>['required','integer','min:1']]);
        $expected=$this->price($d['days']);if($expected===null||$expected!==$d['amount'])return response()->json(['message'=>'Payment details mismatch'],400);
        $p=Payment::where('razorpay_order_id',$d['razorpay_order_id'])->where('user_id',$r->user()->id)->first();if(!$p)return response()->json(['message'=>'Payment order not found'],404);if($p->status==='approved')return response()->json(['message'=>'Payment already processed'],409);
        $secret=config('services.razorpay.key_secret');$signature=hash_hmac('sha256',$d['razorpay_order_id'].'|'.$d['razorpay_payment_id'],(string)$secret);if(!$secret||!hash_equals($signature,$d['razorpay_signature']))return response()->json(['message'=>'Payment verification failed — invalid signature'],400);
        if(Payment::where('razorpay_payment_id',$d['razorpay_payment_id'])->exists())return response()->json(['message'=>'Payment already processed'],409);
        return DB::transaction(function()use($p,$d,$r,$expected){$u=User::findOrFail($r->user()->id);$base=$u->subscription_end_date&&$u->subscription_end_date->isFuture()?$u->subscription_end_date:now();$u->subscription_end_date=$base->copy()->addDays($d['days']);$u->save();$p->fill(['amount'=>$expected,'days_added'=>$d['days'],'status'=>'approved','razorpay_payment_id'=>$d['razorpay_payment_id'],'razorpay_signature'=>$d['razorpay_signature']])->save();return response()->json(['message'=>'Payment verified! Subscription extended.','subscriptionEndDate'=>$u->subscription_end_date,'daysAdded'=>$d['days']]);});
    }

    public function submitUpi(Request $r):JsonResponse
    {
        $d=$r->validate(['days'=>['required','integer','min:1','max:365'],'amount'=>['required','integer','min:1'],'utr_number'=>['nullable','string','max:100'],'screenshot_base64'=>['required','string']]);
        if($this->price($d['days'])!==$d['amount'])return response()->json(['message'=>'Payment details mismatch'],400);
        if(Payment::where('user_id',$r->user()->id)->where('status','pending')->where('method','manual')->exists())return response()->json(['message'=>'You already have a pending payment request. Please wait for admin approval.'],400);
        if(strlen($d['screenshot_base64'])>7_000_000)return response()->json(['message'=>'Screenshot too large. Please compress to under 5MB.'],400);
        if(!preg_match('/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+\/=]+)$/',$d['screenshot_base64'],$m))return response()->json(['message'=>'Invalid screenshot image'],422);
        $bytes=base64_decode($m[2],true);if($bytes===false||strlen($bytes)>5*1024*1024)return response()->json(['message'=>'Screenshot too large or invalid'],400);
        $ext=$m[1]==='jpeg'?'jpg':$m[1];$dir=public_path('uploads/payment_screenshots');if(!is_dir($dir))mkdir($dir,0775,true);$file=Str::uuid().'.'.$ext;file_put_contents($dir.DIRECTORY_SEPARATOR.$file,$bytes);
        Payment::create(['user_id'=>$r->user()->id,'amount'=>$d['amount'],'days_added'=>$d['days'],'status'=>'pending','method'=>'manual','utr_number'=>$d['utr_number']??'','screenshot_url'=>'/uploads/payment_screenshots/'.$file,'notes'=>'Manual UPI payment; UTR: '.($d['utr_number']??'Not provided')]);
        return response()->json(['message'=>'Payment submitted successfully! Admin will verify and activate your plan shortly.'],201);
    }

    public function activate(Request $r,int $id):JsonResponse
    {
        abort_unless($r->user()->role==='admin',403);$p=Payment::findOrFail($id);if($p->status==='approved')return response()->json(['message'=>'Payment already approved'],400);$u=User::findOrFail($p->user_id);
        return DB::transaction(function()use($p,$u,$r){$base=$u->subscription_end_date&&$u->subscription_end_date->isFuture()?$u->subscription_end_date:now();$u->subscription_end_date=$base->copy()->addDays($p->days_added);$u->save();$p->status='approved';$p->approved_by=$r->user()->id;$p->save();return response()->json(['message'=>'Plan activated','subscriptionEndDate'=>$u->subscription_end_date]);});
    }
    public function reject(Request $r,int $id):JsonResponse{abort_unless($r->user()->role==='admin',403);$p=Payment::findOrFail($id);$p->status='rejected';$p->notes=trim(($p->notes??'').' [Rejected by admin]');$p->save();return response()->json(['message'=>'Payment rejected.']);}
    private function price(int $days):?int{return $days===365?16999:($days>=1&&$days<365?$days*69:null);}
}
