<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class LivekitController extends Controller
{
    public function webhook(Request $r):JsonResponse
    {
        $secret=config('services.livekit.secret');$key=config('services.livekit.key');$header=(string)$r->header('Authorization');$token=preg_replace('/^Bearer\s+/i','',$header);$parts=explode('.',$token);
        if(!$secret||!$key||count($parts)!==3)return response()->json(['message'=>'Invalid LiveKit webhook authorization'],401);
        $signature=rtrim(strtr(base64_encode(hash_hmac('sha256',$parts[0].'.'.$parts[1],$secret,true)),'+/','-_'),'=');
        if(!hash_equals($signature,$parts[2]))return response()->json(['message'=>'Invalid LiveKit webhook signature'],401);
        $claims=json_decode(base64_decode(strtr($parts[1],'-_','+/')),true)?:[];
        if(($claims['iss']??null)!==$key||($claims['exp']??0)<time())return response()->json(['message'=>'Expired or invalid LiveKit webhook'],401);
        $raw=(string)$r->getContent();if(!empty($claims['sha256'])&&!hash_equals(strtolower((string)$claims['sha256']),hash('sha256',$raw)))return response()->json(['message'=>'Webhook body signature mismatch'],401);
        $payload=$r->all();$event=$payload['event']??'';$room=$payload['room']['name']??'';$participant=$payload['participant']??[];
        if(!$room||!in_array($event,['participant_joined','participant_left'],true))return response()->json(['received'=>true]);
        $identity=(string)($participant['identity']??'');$user=ctype_digit($identity)?User::find((int)$identity):null;$username=(string)($participant['name']??$identity);
        $attendance=Attendance::firstOrCreate(['room_id'=>$room],['teacher_id'=>$user?->id,'session_title'=>$room,'session_date'=>now(),'records'=>[]]);$records=$attendance->records??[];
        if($event==='participant_joined'){
            $active=false;foreach($records as $rec){if((string)($rec['identity']??$rec['userId']??'')===$identity&&empty($rec['leftAt'])){$active=true;break;}}
            if(!$active)$records[]=['userId'=>$user?->id,'identity'=>$identity,'username'=>$username,'role'=>$user?->role??'student','joinedAt'=>now()->toIso8601String(),'leftAt'=>null,'duration'=>0];
        }else{
            for($i=count($records)-1;$i>=0;$i--){if((string)($records[$i]['identity']??$records[$i]['userId']??'')===$identity&&empty($records[$i]['leftAt'])){$records[$i]['leftAt']=now()->toIso8601String();$joined=\Illuminate\Support\Carbon::parse($records[$i]['joinedAt']);$records[$i]['duration']=max(0,$joined->diffInSeconds(now()));break;}}
        }
        $attendance->records=$records;$attendance->save();return response()->json(['received'=>true]);
    }

    public function token(Request $r):JsonResponse
    {
        $d=$r->validate(['room'=>['required','string','max:190'],'username'=>['nullable','string','max:190']]);$key=config('services.livekit.key');$secret=config('services.livekit.secret');
        if(!$key||!$secret||!config('services.livekit.url'))return response()->json(['message'=>'LiveKit is not configured'],503);
        $identity=$d['username']??$r->user()->name;$now=time();$token=$this->jwt(['iss'=>$key,'sub'=>(string)$r->user()->id,'name'=>$identity,'nbf'=>$now-5,'exp'=>$now+3600,'video'=>['roomJoin'=>true,'room'=>$d['room'],'canPublish'=>true,'canSubscribe'=>true,'canPublishData'=>true]],$secret);
        return response()->json(['token'=>$token,'url'=>config('services.livekit.url'),'serverUrl'=>config('services.livekit.url')]);
    }

    public function createRoom(Request $r):JsonResponse
    {
        abort_unless(in_array($r->user()->role,['teacher','admin'],true),403);$d=$r->validate(['name'=>['required','string','max:190'],'empty_timeout'=>['nullable','integer','min:60'],'max_participants'=>['nullable','integer','min:1','max:1000']]);$url=config('services.livekit.url');$key=config('services.livekit.key');$secret=config('services.livekit.secret');if(!$url||!$key||!$secret)return response()->json(['message'=>'LiveKit is not configured'],503);
        $jwt=$this->jwt(['iss'=>$key,'sub'=>'tuition-meet-api','nbf'=>time()-5,'exp'=>time()+300,'video'=>['roomCreate'=>true,'room'=>$d['name']]],$secret);
        $res=Http::withToken($jwt)->post(rtrim($url,'/').'/twirp/livekit.RoomService/CreateRoom',['name'=>$d['name'],'empty_timeout'=>$d['empty_timeout']??600,'max_participants'=>$d['max_participants']??20]);if(!$res->successful())return response()->json(['message'=>'Unable to create LiveKit room'],502);
        $room=$res->json();return response()->json(['message'=>'Room created successfully','room'=>['name'=>$room['name']??$d['name'],'sid'=>$room['sid']??'pending']],201);
    }

    public function listRooms(Request $r):JsonResponse
    {
        $url=config('services.livekit.url');$key=config('services.livekit.key');$secret=config('services.livekit.secret');if(!$url||!$key||!$secret)return response()->json(['rooms'=>[]]);
        $jwt=$this->jwt(['iss'=>$key,'sub'=>'tuition-meet-api','nbf'=>time()-5,'exp'=>time()+300,'video'=>['roomList'=>true]],$secret);$res=Http::withToken($jwt)->post(rtrim($url,'/').'/twirp/livekit.RoomService/ListRooms',[]);if(!$res->successful())return response()->json(['message'=>'Unable to list LiveKit rooms'],502);$rooms=$res->json('rooms',[]);return response()->json(['rooms'=>array_map(fn($x)=>['name'=>$x['name']??'','sid'=>$x['sid']??'','num_participants'=>$x['numParticipants']??0],$rooms)]);
    }

    public function deleteRoom(Request $r):JsonResponse
    {
        abort_unless(in_array($r->user()->role,['teacher','admin'],true),403);$d=$r->validate(['room'=>['required','string','max:190']]);$url=config('services.livekit.url');$key=config('services.livekit.key');$secret=config('services.livekit.secret');if(!$url||!$key||!$secret)return response()->json(['message'=>'LiveKit is not configured'],503);
        $jwt=$this->jwt(['iss'=>$key,'sub'=>'tuition-meet-api','nbf'=>time()-5,'exp'=>time()+300,'video'=>['roomDelete'=>true,'room'=>$d['room']]],$secret);$res=Http::withToken($jwt)->post(rtrim($url,'/').'/twirp/livekit.RoomService/DeleteRoom',['room'=>$d['room']]);return $res->successful()?response()->json(['message'=>'Room deleted']):response()->json(['message'=>'Unable to delete LiveKit room'],502);
    }

    private function jwt(array $payload,string $secret):string{$enc=fn($v)=>rtrim(strtr(base64_encode(json_encode($v,JSON_UNESCAPED_SLASHES)),'+/','-_'),'=');$head=$enc(['alg'=>'HS256','typ'=>'JWT']);$body=$enc($payload);$sig=rtrim(strtr(base64_encode(hash_hmac('sha256',"$head.$body",$secret,true)),'+/','-_'),'=');return "$head.$body.$sig";}
}
