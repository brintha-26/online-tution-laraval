<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class AuthController extends Controller
{
    public function signup(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name' => ['required','string','max:150'],
            'email' => ['required','email','max:190','unique:users,email'],
            'password' => ['required','string','min:6'],
            'role' => ['sometimes','in:student,teacher'],
        ]);
        $data['email'] = strtolower(trim($data['email']));
        $user = User::create($data + ['role' => $data['role'] ?? 'student', 'is_approved' => true, 'trial_start_date' => now()]);
        return $this->tokenResponse($user, 201);
    }

    public function login(Request $request): JsonResponse
    {
        $data = $request->validate(['email' => ['required','email'], 'password' => ['required','string'], 'role' => ['required','in:student,teacher,admin']]);
        $user = User::where('email', strtolower($data['email']))->first();
        if (!$user || !password_verify($data['password'], $user->password) || $user->role !== $data['role']) {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }
        $user->forceFill(['last_active' => now()])->save();
        if ($user->role === 'student' && !$user->hasActiveAccess()) {
            return response()->json(['message' => 'Your 7-day trial has expired. Please contact your admin to restore access.', 'trialExpired' => true], 403);
        }
        return $this->tokenResponse($user);
    }

    public function me(Request $request): JsonResponse
    {
        return response()->json(['user' => $this->userPayload($request->user())]);
    }

    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()?->delete();
        return response()->json(['message' => 'Logged out']);
    }

    public function forgotPassword(Request $request): JsonResponse
    {
        $request->validate(['email' => ['required','email']]);
        $user = User::where('email', strtolower($request->email))->first();
        if (!$user) return response()->json(['message' => 'No account found with this email'], 404);
        if (!$user->otp_reset_window || $user->otp_reset_window->isPast()) {
            $user->otp_request_count = 0;
            $user->otp_reset_window = now()->addHour();
        }
        if ($user->otp_request_count >= 3) return response()->json(['message' => 'Too many OTP requests. Try again in 1 hour.'], 429);
        $otp = (string) random_int(100000, 999999);
        $user->otp_request_count++;
        $user->reset_otp = $otp;
        $user->reset_otp_expiry = now()->addMinutes(10);
        $user->save();
        if (config('mail.default') === 'log' || !config('mail.mailers.smtp.host')) {
            if (app()->environment('local')) return response()->json(['message' => 'OTP generated for local development', 'emailSent' => false, 'devOtp' => $otp]);
            return response()->json(['message' => 'Email service is not configured'], 503);
        }
        try {
            Mail::raw("Your Tuition Meet password reset code is {$otp}. It expires in 10 minutes.", function ($message) use ($user): void {
                $message->to($user->email)->subject('Tuition Meet password reset code');
            });
            return response()->json(['message' => 'OTP sent to your email', 'emailSent' => true]);
        } catch (\Throwable $e) {
            if (app()->environment('local')) return response()->json(['message' => 'OTP generated for local development', 'emailSent' => false, 'devOtp' => $otp]);
            report($e);
            return response()->json(['message' => 'Failed to send reset code. Check mail configuration.'], 500);
        }
    }

    public function resetPassword(Request $request): JsonResponse
    {
        $request->validate(['email' => ['required','email'], 'otp' => ['required','digits:6'], 'new_password' => ['required','string','min:6']]);
        $user = User::where('email', strtolower($request->email))->first();
        if (!$user) return response()->json(['message' => 'User not found'], 404);
        if (!$user->reset_otp || !hash_equals((string) $user->reset_otp, (string) $request->otp)) return response()->json(['message' => 'Invalid OTP'], 400);
        if (!$user->reset_otp_expiry || $user->reset_otp_expiry->isPast()) return response()->json(['message' => 'OTP has expired'], 400);
        $user->password = $request->new_password;
        $user->reset_otp = null;
        $user->reset_otp_expiry = null;
        $user->save();
        $user->tokens()->delete();
        return response()->json(['message' => 'Password reset successfully! You can now log in.']);
    }

    public function verifyOtp(Request $request): JsonResponse
    {
        $request->validate(['email' => ['required','email'], 'otp' => ['required','digits:6']]);
        $user = User::where('email', strtolower($request->email))->first();
        if (!$user) return response()->json(['message' => 'User not found'], 404);
        if (!$user->reset_otp || !hash_equals((string) $user->reset_otp, (string) $request->otp)) return response()->json(['message' => 'Invalid OTP'], 400);
        if (!$user->reset_otp_expiry || $user->reset_otp_expiry->isPast()) return response()->json(['message' => 'OTP has expired. Please request a new one.'], 400);
        return response()->json(['message' => 'OTP verified', 'verified' => true]);
    }

    private function tokenResponse(User $user, int $status = 200): JsonResponse
    {
        return response()->json(['token' => $user->createToken('web')->plainTextToken, 'user' => $this->userPayload($user)], $status);
    }

    private function userPayload(User $user): array
    {
        return [
            'id' => $user->id, 'name' => $user->name, 'email' => $user->email, 'role' => $user->role,
            'trialStartDate' => $user->trial_start_date, 'subscriptionEndDate' => $user->subscription_end_date,
        ];
    }
}
