<?php
namespace App\Models;
class Assignment extends ApiRecord { protected $table = 'assignments'; public function ownerField(): ?string { return 'teacher_id'; } }
