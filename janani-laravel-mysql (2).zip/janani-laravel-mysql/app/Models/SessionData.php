<?php
namespace App\Models;
class SessionData extends ApiRecord { protected $table = 'session_data'; public function ownerField(): ?string { return 'teacher_id'; } }
