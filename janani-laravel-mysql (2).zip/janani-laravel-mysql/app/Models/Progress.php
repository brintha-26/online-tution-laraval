<?php
namespace App\Models;
class Progress extends ApiRecord { protected $table = 'progress'; public function ownerField(): ?string { return 'student_id'; } }
