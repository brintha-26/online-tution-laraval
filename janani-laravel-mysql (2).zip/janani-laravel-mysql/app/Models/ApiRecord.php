<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

abstract class ApiRecord extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['attachments' => 'array','records' => 'array','syllabus' => 'array','lessons' => 'array','schedule' => 'array','enrolled_students' => 'array','highlights' => 'array','chat_history' => 'array','action_items' => 'array','read' => 'boolean','watched' => 'boolean','grade' => 'decimal:2','session_date' => 'datetime','due_date' => 'datetime','submitted_at' => 'datetime','graded_at' => 'datetime','completed_at' => 'datetime'];
    public function ownerField(): ?string { return 'user_id'; }
}
