<?php
namespace App\Models;
class Subject extends ApiRecord { protected $table = 'subjects'; public function ownerField(): ?string { return 'teacher_id'; } }
