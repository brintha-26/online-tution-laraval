<?php
namespace App\Models;
class Attendance extends ApiRecord { protected $table = 'attendance'; public function ownerField(): ?string { return 'teacher_id'; } }
