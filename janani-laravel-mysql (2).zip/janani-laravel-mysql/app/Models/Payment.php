<?php
namespace App\Models;
class Payment extends ApiRecord { protected $table = 'payments'; }
