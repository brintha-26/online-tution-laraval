<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = ['name','email','password','role','is_approved','trial_start_date','subscription_end_date','avatar','last_active','reset_otp','reset_otp_expiry','otp_request_count','otp_reset_window','legacy_uid'];
    protected $hidden = ['password','remember_token'];
    protected function casts(): array { return ['email_verified_at' => 'datetime','password' => 'hashed','is_approved' => 'boolean','trial_start_date' => 'datetime','subscription_end_date' => 'datetime','last_active' => 'datetime','reset_otp_expiry' => 'datetime','otp_reset_window' => 'datetime']; }
    public function hasActiveAccess(): bool { return ($this->trial_start_date && $this->trial_start_date->copy()->addDays(7)->isFuture()) || ($this->subscription_end_date && $this->subscription_end_date->isFuture()); }
}
