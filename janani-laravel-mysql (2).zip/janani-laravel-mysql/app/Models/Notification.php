<?php
namespace App\Models;
class Notification extends ApiRecord { protected $table = 'notifications'; }
