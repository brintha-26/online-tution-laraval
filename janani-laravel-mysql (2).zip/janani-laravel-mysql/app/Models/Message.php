<?php
namespace App\Models;
class Message extends ApiRecord { protected $table = 'messages'; public function ownerField(): ?string { return null; } }
