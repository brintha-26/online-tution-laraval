<?php
namespace App\Models;
class Submission extends ApiRecord { protected $table = 'submissions'; public function ownerField(): ?string { return 'student_id'; } }
