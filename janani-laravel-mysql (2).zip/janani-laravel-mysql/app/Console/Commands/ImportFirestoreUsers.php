<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class ImportFirestoreUsers extends Command
{
    protected $signature = 'users:import-firestore {file : JSON file containing exported Firestore users}';
    protected $description = 'Import a JSON export of the old Firestore users collection into MySQL';

    public function handle(): int
    {
        $path=$this->argument('file');
        if(!is_file($path)){$this->error('Export file not found: '.$path);return self::FAILURE;}
        $doc=json_decode(file_get_contents($path),true);
        if(!is_array($doc)){$this->error('The file is not valid JSON.');return self::FAILURE;}
        $rows=$doc['documents']??$doc['users']??$doc;
        if(!is_array($rows)){$this->error('Expected a JSON array, users object, or Firestore documents array.');return self::FAILURE;}
        $created=0;$updated=0;$skipped=0;
        foreach($rows as $key=>$row){
            if(!is_array($row)){$skipped++;continue;}
            $fields=$row['fields']??$row;
            $fields=$this->decodeFields($fields);
            $email=strtolower(trim((string)($fields['email']??'')));
            $password=(string)($fields['password']??'');
            if(!$email||!filter_var($email,FILTER_VALIDATE_EMAIL)||!$password){$skipped++;continue;}
            $legacy=(string)($row['id']??$row['name']??$key);
            if(str_contains($legacy,'/'))$legacy=basename($legacy);
            $existing=DB::table('users')->where('email',$email)->first();
            $record=[
                'name'=>substr((string)($fields['name']??'User'),0,150),'email'=>$email,
                'password'=>preg_match('/^\$2[aby]\$/',$password)?$password:Hash::make($password),
                'role'=>in_array(($fields['role']??'student'),['student','teacher','admin'],true)?$fields['role']:'student',
                'is_approved'=>(bool)($fields['isApproved']??$fields['is_approved']??true),
                'trial_start_date'=>$this->dateValue($fields['trialStartDate']??$fields['trial_start_date']??null),
                'subscription_end_date'=>$this->dateValue($fields['subscriptionEndDate']??$fields['subscription_end_date']??null),
                'avatar'=>$fields['avatar']??null,'legacy_uid'=>$legacy,'updated_at'=>now(),'created_at'=>now(),
            ];
            if($existing){unset($record['created_at']);DB::table('users')->where('id',$existing->id)->update($record);$updated++;}
            else{DB::table('users')->insert($record);$created++;}
        }
        $this->info("Firestore user import done. New: {$created}; updated: {$updated}; skipped: {$skipped}.");
        return self::SUCCESS;
    }

    private function decodeFields(array $fields): array
    {
        $out=[];foreach($fields as $key=>$value){if(is_array($value)&&count($value)===1){$type=array_key_first($value);$value=match($type){'stringValue','integerValue','doubleValue','booleanValue','timestampValue'=>$value[$type],'nullValue'=>null,'mapValue'=>$this->decodeFields($value[$type]['fields']??[]),'arrayValue'=>array_map(fn($x)=>$this->decodeFields($x['mapValue']['fields']??[])?:($x[array_key_first($x)]??null),$value[$type]['values']??[]),default=>$value};}$out[$key]=$value;}return $out;
    }
    private function dateValue(mixed $value): ?string{if(!$value)return null;try{return \Illuminate\Support\Carbon::parse($value)->toDateTimeString();}catch(\Throwable){return null;}}
}
