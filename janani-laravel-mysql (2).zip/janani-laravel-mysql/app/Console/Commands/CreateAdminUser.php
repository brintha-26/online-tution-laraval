<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class CreateAdminUser extends Command
{
    protected $signature='users:create-admin {email} {name?}';
    protected $description='Create an administrator account without a hard-coded default password';
    public function handle():int
    {
        $email=strtolower(trim($this->argument('email')));
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)){$this->error('Enter a valid email.');return self::FAILURE;}
        if(User::where('email',$email)->exists()){$this->error('That email is already registered.');return self::FAILURE;}
        $password=$this->secret('Admin password (minimum 10 characters)');
        if(strlen((string)$password)<10){$this->error('Password must have at least 10 characters.');return self::FAILURE;}
        $user=User::create(['name'=>$this->argument('name')?:'Administrator','email'=>$email,'password'=>$password,'role'=>'admin','is_approved'=>true,'trial_start_date'=>now()]);
        $this->info('Admin account created: '.$user->email);return self::SUCCESS;
    }
}
