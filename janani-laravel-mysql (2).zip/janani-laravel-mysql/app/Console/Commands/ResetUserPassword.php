<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class ResetUserPassword extends Command
{
    protected $signature='users:reset-password {email}';
    protected $description='Reset a local user password using a hidden terminal prompt';

    public function handle(): int
    {
        $email=strtolower(trim($this->argument('email')));
        $user=User::where('email',$email)->first();
        if(!$user){$this->error('No user found with that email.');return self::FAILURE;}
        $password=$this->secret('New password (minimum 10 characters)');
        if(strlen((string)$password)<10){$this->error('Password must have at least 10 characters.');return self::FAILURE;}
        $user->password=$password;
        $user->save();
        $user->tokens()->delete();
        $this->info('Password updated for '.$user->email);
        return self::SUCCESS;
    }
}
