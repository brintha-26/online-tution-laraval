<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use App\Http\Middleware\ApiCaseTransformer;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(web: __DIR__.'/../routes/web.php', api: __DIR__.'/../routes/api.php', commands: __DIR__.'/../routes/console.php', health: '/up')
    ->withCommands([App\Console\Commands\ImportFirestoreUsers::class, App\Console\Commands\CreateAdminUser::class, App\Console\Commands\ResetUserPassword::class])
    ->withMiddleware(function (Middleware $middleware): void {
        // API uses Sanctum bearer tokens; browser session/CSRF middleware is not needed.
        $middleware->append(ApiCaseTransformer::class);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(fn (Request $request, \Throwable $exception): bool =>
            $request->is('api/*') || $request->expectsJson()
        );
    })->create();
