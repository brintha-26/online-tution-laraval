# Tuition Meet Laravel + MySQL API

This Laravel 12 API serves the included production React build from `public/` and stores application records in MySQL. It replaces the old Express API routes for accounts, subjects, assignments/submissions, notifications, chat history, sessions, attendance records, progress, analytics, admin access and payments. The old project had Firestore-backed user records and mostly in-memory records for other collections; those memory-only records cannot be recovered after the old process exits.

## Run locally

Requirements: PHP 8.2+, Composer, MySQL 8+.

```powershell
composer install
Copy-Item .env.example .env
php artisan key:generate
```

Create a MySQL database named `tuition_meet`, then set `DB_DATABASE`, `DB_USERNAME`, and `DB_PASSWORD` in `.env`.

```powershell
php artisan migrate
php artisan serve --host=127.0.0.1 --port=8000
```

Open `http://127.0.0.1:8000`. The frontend API client uses same-origin `/api` requests. The CSS hotfix is applied to the built files under `public`; keep the original React source separately so future UI updates can be rebuilt cleanly.

### Realtime relay

The compiled client uses Socket.IO for private chat, typing state, live-session presence and end-session events. Run the included authenticated relay in a second terminal:

```powershell
Set-Location .\realtime
Copy-Item .env.example .env
npm install
npm start
```

Set `REALTIME_SHARED_SECRET` to the **same random value** in the Laravel root `.env` and `realtime/.env`. The relay validates each socket bearer token against Laravel's `/api/auth/me`; it does not store application data. For deployment, set the realtime URL/origin in the compiled frontend using the original React source when available.

## Connected services

For video rooms and access tokens, copy the old `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`, and `LIVEKIT_URL` values into this project's `.env`. Configure a LiveKit webhook pointing at `/api/livekit/webhook` on a publicly reachable HTTPS host if you need server-recorded attendance join/leave events. Localhost is not reachable from LiveKit Cloud.

Online Razorpay payments require `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET`; these keys were not present in the supplied `.env.example`, so add them only if you have them. Manual UPI proof is stored under `public/uploads/payment_screenshots`.

For email OTP, copy `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, and `FROM_EMAIL` from the old environment into this project's `.env`. Without SMTP, local development returns a `devOtp` for password reset.

## Import old Firestore users

The included exporter needs a Firebase service-account JSON key. In Firebase Console, open Project settings → Service accounts → Generate new private key. Keep the downloaded key private. From the project root, run:

```powershell
Set-Location .\tools
npm install
$env:FIREBASE_SERVICE_ACCOUNT_FILE='C:\path\to\firebase-service-account.json'
$env:GOOGLE_CLOUD_PROJECT='your-firebase-project-id'
npm run export-users -- C:\path\to\firestore-users.json
```

Then return to the project root and import that JSON file:

```powershell
php artisan users:import-firestore C:\path\to\firestore-users.json
```

The importer preserves existing bcrypt hashes, records the old Firestore document id in `legacy_uid`, and upserts by email. It does not import other data: the old assignments, payments, chats, attendance, subjects, notifications, progress and sessions were held in process memory rather than a durable database.

If the Firestore users export is unavailable, create a new admin account interactively (the password is entered as a hidden terminal prompt):

```powershell
php artisan users:create-admin admin@example.com "Site Admin"
```

To reset an existing local account password from the backend terminal:

```powershell
php artisan users:reset-password admin@example.com
```

## Important limits before production

- The original React `src/` tree and build configuration were not included; only the compiled `dist/` was supplied. The included frontend build was adjusted directly, so UI changes should be made in the original source and rebuilt when that source is recovered.
- LiveKit and Razorpay require valid external service credentials. LiveKit attendance webhooks need a reachable HTTPS URL.
- Socket.IO is handled by the included small Node relay because the supplied compiled frontend expects the Socket.IO protocol. All REST APIs and persistent application data remain Laravel/MySQL. LiveKit participant attendance requires the public webhook described above.
- Review mail delivery, payment webhook/signature settings, backups, `APP_DEBUG=false`, and HTTPS before production deployment.

## Docker deployment

Docker Compose files are included. For a local container run, install Docker Desktop and use:

```powershell
Copy-Item .env.example .env
Copy-Item realtime/.env.example realtime/.env
composer install
php artisan key:generate
# Set MYSQL_ROOT_PASSWORD, MYSQL_PASSWORD, and the same REALTIME_SHARED_SECRET in both env files.
docker compose -f compose.yaml -f compose.dev.yaml up --build
```

Open `http://127.0.0.1:8080`. The app container waits for MySQL, runs Laravel migrations, and serves the included website. The realtime relay runs separately on port 5001. MySQL data and payment screenshot uploads use named volumes.

For a public VPS deployment, use a Linux host with Docker Compose v2 and two DNS A records pointing to its public IP. Set `APP_DOMAIN`, `REALTIME_DOMAIN`, `DEPLOY_APP_URL=https://<APP_DOMAIN>`, and `REALTIME_PUBLIC_URL=https://<REALTIME_DOMAIN>` in the private root `.env`. Set real LiveKit, Razorpay and SMTP credentials there as needed; keep `APP_DEBUG=false`. Then run:

```sh
docker compose --profile production up -d --build
```

Caddy terminates HTTPS on ports 80/443 and routes the app and Socket.IO relay to their containers. MySQL is not published to the public host ports. Configure the LiveKit webhook as `https://<APP_DOMAIN>/api/livekit/webhook`. After the first start, import Firestore users and create/verify an admin in the production database; the locally created admin is only in local MySQL:

```sh
docker compose cp tools/firestore-users.json api:/tmp/firestore-users.json
docker compose exec api php artisan users:import-firestore /tmp/firestore-users.json
docker compose exec api php artisan users:create-admin admin@example.com "Site Admin"
```
